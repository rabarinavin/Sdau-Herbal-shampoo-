package com.sdau.herbal

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.Color
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController

private data class Tab(val route: String, val label: String, val icon: ImageVector)

private val tabs = listOf(
    Tab("home", "Home", Icons.Filled.Home),
    Tab("product", "Product", Icons.Filled.Favorite),
    Tab("cost", "Costing", Icons.Filled.ShoppingCart),
    Tab("stock", "Stock", Icons.AutoMirrored.Filled.List)
)

private val titles = mapOf(
    "home" to "SDAU Herbal Shampoo", "product" to "Product Details", "process" to "Manufacturing Process",
    "cost" to "Cost & Profit Estimate", "stock" to "Inventory", "present" to "Project Presentation", "about" to "About"
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SdauApp(store: Store) {
    val nav = rememberNavController()
    val route = nav.currentBackStackEntryAsState().value?.destination?.route
    val isTab = tabs.any { it.route == route }
    fun go(r: String) = nav.navigate(r) {
        if (tabs.any { it.route == r }) {
            popUpTo("home") { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }
    Scaffold(
        containerColor = Cream,
        topBar = {
            if (route != null && route != "splash") CenterAlignedTopAppBar(
                title = { Text(titles[route] ?: "") },
                navigationIcon = {
                    if (!isTab) IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = Forest, titleContentColor = Cream, navigationIconContentColor = Cream
                )
            )
        },
        bottomBar = {
            if (isTab) NavigationBar(containerColor = Forest) {
                tabs.forEach { t ->
                    NavigationBarItem(
                        selected = route == t.route, onClick = { go(t.route) },
                        icon = { Icon(t.icon, t.label) }, label = { Text(t.label) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Forest, selectedTextColor = Cream, indicatorColor = Gold,
                            unselectedIconColor = Cream.copy(alpha = 0.75f), unselectedTextColor = Cream.copy(alpha = 0.75f)
                        )
                    )
                }
            }
        }
    ) { pad ->
        NavHost(nav, "splash", if (route == "splash") Modifier else Modifier.padding(pad)) {
            composable("splash") { Splash { nav.navigate("home") { popUpTo("splash") { inclusive = true } } } }
            composable("home") { Home(::go) }
            composable("product") { ProductScreen(store) }
            composable("process") { ProcessScreen() }
            composable("cost") { CostScreen() }
            composable("stock") { StockScreen(store) }
            composable("present") { PresentScreen(store) }
            composable("about") { AboutScreen(store) }
        }
    }
}
