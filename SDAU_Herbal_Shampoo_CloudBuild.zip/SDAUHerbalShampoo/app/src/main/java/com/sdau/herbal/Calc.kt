package com.sdau.herbal

import java.text.NumberFormat
import java.util.Locale

/** Pure calculation logic. All results are estimates. */
object Calc {
    private val india: Locale = Locale.Builder().setLanguage("en").setRegion("IN").build()

    fun num(s: String): Double = s.trim().toDoubleOrNull()?.takeIf { it.isFinite() && it >= 0 } ?: 0.0
    fun count(s: String): Int = s.trim().toIntOrNull()?.takeIf { it >= 0 } ?: 0
    fun inr(v: Double): String = NumberFormat.getCurrencyInstance(india).format(if (v.isFinite()) v else 0.0)

    data class Result(val total: Double, val perBottle: Double, val soldUsed: Int, val revenue: Double, val profit: Double)

    fun compute(costs: List<Double>, produced: Int, sold: Int, price: Double): Result {
        val total = costs.sum()
        val per = if (produced > 0) total / produced else 0.0
        val soldUsed = minOf(sold, produced)
        val revenue = price * soldUsed
        return Result(total, per, soldUsed, revenue, revenue - per * soldUsed)
    }
}
