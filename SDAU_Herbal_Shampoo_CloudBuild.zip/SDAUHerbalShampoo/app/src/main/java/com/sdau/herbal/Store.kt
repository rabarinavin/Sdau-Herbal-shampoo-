package com.sdau.herbal

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

private val Context.ds by preferencesDataStore("sdau_prefs")

/** Simple local key-value storage for all editable content. */
class Store(private val context: Context) {
    fun flow(key: String, def: String): Flow<String> =
        context.ds.data
            .catch { if (it is IOException) emit(emptyPreferences()) else throw it }
            .map { it[stringPreferencesKey(key)] ?: def }

    suspend fun set(key: String, value: String) {
        context.ds.edit { it[stringPreferencesKey(key)] = value }
    }
}
