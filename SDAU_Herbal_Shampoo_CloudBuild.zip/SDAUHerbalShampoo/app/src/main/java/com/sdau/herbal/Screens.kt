package com.sdau.herbal

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun Splash(onDone: () -> Unit) {
    var show by remember { mutableStateOf(false) }
    val a by animateFloatAsState(if (show) 1f else 0f, tween(900), label = "fade")
    LaunchedEffect(Unit) { show = true; delay(1900); onDone() }
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Forest, Olive))), Alignment.Center) {
        Column(Modifier.alpha(a), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("🌿", fontSize = 72.sp)
            Spacer(Modifier.height(12.dp))
            Text("SDAU Herbal Shampoo", fontFamily = FontFamily.Serif, fontSize = 28.sp, color = Cream)
            Text("100 ml", fontSize = 16.sp, color = Gold)
        }
    }
}

@Composable
fun Home(go: (String) -> Unit) = Page {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp))
            .background(Brush.verticalGradient(listOf(Forest, Olive))).padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Placeholder("Official SDAU logo placeholder", 96, "LOGO")
        Text("SDAU Herbal Shampoo", fontFamily = FontFamily.Serif, fontSize = 26.sp, color = Cream, textAlign = TextAlign.Center)
        Text("Premium herbal care", color = Gold)
    }
    Card(
        Modifier.fillMaxWidth().clickable { go("product") }, shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White)
    ) {
        Row(Modifier.padding(14.dp), horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Placeholder("Product image placeholder", 96, "🧴")
            Column {
                Text("Herbal Shampoo", fontFamily = FontFamily.Serif, fontSize = 20.sp, color = Forest)
                Text("100 ml bottle", color = Olive)
                Text("Tap for details", fontSize = 12.sp)
            }
        }
    }
    listOf("Manufacturing" to "process", "Cost calculator" to "cost", "Inventory" to "stock", "Presentation" to "present", "About" to "about")
        .chunked(2).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                row.forEach { (label, r) ->
                    Card(
                        Modifier.weight(1f).heightIn(min = 72.dp).clickable { go(r) }, shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = Olive)
                    ) { Box(Modifier.fillMaxSize().padding(14.dp), Alignment.CenterStart) { Text(label, color = Cream, fontSize = 16.sp) } }
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    Section("Project overview") {
        Text("A college entrepreneurship demo: a 100 ml herbal shampoo concept with product details, a process overview, a cost estimator and a simple stock record.")
    }
}

@Composable
fun ProductScreen(store: Store) = Page {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) { Placeholder("Product image placeholder", 160, "🧴") }
    Text("SDAU Herbal Shampoo", fontFamily = FontFamily.Serif, fontSize = 24.sp, color = Forest)
    Text("Size: 100 ml", color = Olive)
    Note("Draft content. Ingredients and usage must be confirmed against the actual formulation and label. No safety or efficacy claims are made.")
    EditableField(store, "p_desc", "Description (editable)", "A herbal shampoo concept created as a student entrepreneurship project.", 3)
    EditableField(store, "p_ingr", "Ingredients (draft, to be confirmed)", "Aloe Vera, Neem, Curry Leaves, Tulsi, Flaxseed, Shampoo Base, Floral Fragrance", 3)
    EditableField(store, "p_use", "Instructions for use (draft)", "Wet hair, apply a small amount, massage gently and rinse well. Avoid contact with eyes. Stop use if irritation occurs.", 4)
}

@Composable
fun ProcessScreen() = Page {
    Note("Project overview only. This is not a validated manufacturing SOP and gives no quantities, temperatures, preservative levels or shelf life.")
    listOf(
        "Ingredient preparation" to "Select, clean and prepare the herbal ingredients.",
        "Herbal extract preparation" to "Prepare the herbal extract as per the confirmed formulation.",
        "Mixing with shampoo base" to "Combine the extract with the shampoo base.",
        "Fragrance addition" to "Add fragrance only if compatible with the formulation.",
        "Quality checks" to "Check appearance, smell and consistency of the batch.",
        "Filling and packaging" to "Fill 100 ml bottles, cap, label and pack."
    ).forEachIndexed { i, (t, d) -> Section("Step ${i + 1}: $t") { Text(d) } }
}

@Composable
fun CostScreen() = Page {
    val base = rs(); val herbs = rs(); val add = rs(); val bottle = rs(); val label = rs(); val other = rs()
    val produced = rs(); val sold = rs(); val price = rs()
    Note("All figures are estimates based on the values you enter.")
    NumField("Shampoo base cost (₹)", base); NumField("Herbal ingredients cost (₹)", herbs)
    NumField("Fragrance and other additives (₹)", add); NumField("Bottle and cap cost (₹)", bottle)
    NumField("Label and packaging cost (₹)", label); NumField("Other expenses (₹)", other)
    NumField("Bottles produced", produced, false); NumField("Bottles sold (estimate)", sold, false)
    NumField("Selling price per bottle (₹)", price)
    val p = Calc.count(produced.value)
    val r = Calc.compute(listOf(base, herbs, add, bottle, label, other).map { Calc.num(it.value) }, p, Calc.count(sold.value), Calc.num(price.value))
    Section("Estimated results") {
        Text("Total batch cost: ${Calc.inr(r.total)}")
        Text("Cost per bottle: ${Calc.inr(r.perBottle)}")
        Text("Revenue (${r.soldUsed} sold): ${Calc.inr(r.revenue)}")
        Text("Estimated profit: ${Calc.inr(r.profit)}", color = if (r.profit < 0) androidx.compose.ui.graphics.Color(0xFFB3261E) else Forest)
        if (p == 0) Text("Enter bottles produced to see cost per bottle.", fontSize = 12.sp)
        if (Calc.count(sold.value) > p && p > 0) Text("Sold is more than produced; only produced bottles are counted.", fontSize = 12.sp)
    }
}

@Composable
fun StockScreen(store: Store) = Page {
    val produced by store.flow("inv_produced", "50").collectAsState("50")
    val sold by store.flow("inv_sold", "20").collectAsState("20")
    val unit by store.flow("inv_unit", "120").collectAsState("120")
    val real by store.flow("inv_real", "false").collectAsState("false")
    val scope = rememberCoroutineScope()
    Note(if (real == "true") "Marked as real data entered by you." else "DEMO DATA: sample numbers, not real sales. Replace them and switch on 'Real data'.")
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("Real data", Modifier.weight(1f))
        Switch(real == "true", { scope.launch { store.set("inv_real", it.toString()) } })
    }
    EditableField(store, "inv_produced", "Bottles produced", "50", numeric = true)
    EditableField(store, "inv_sold", "Bottles sold", "20", numeric = true)
    EditableField(store, "inv_unit", "Value per bottle (₹)", "120", numeric = true)
    val p = Calc.count(produced); val s = Calc.count(sold)
    Section("Stock summary (estimate)") {
        Text("Remaining stock: ${maxOf(p - s, 0)} bottles")
        Text("Estimated stock value: ${Calc.inr(maxOf(p - s, 0) * Calc.num(unit))}")
        if (s > p) Text("Sold is more than produced. Please check the numbers.", fontSize = 12.sp)
    }
}

@Composable
fun PresentScreen(store: Store) = Page {
    Note("Editable sample text. Add only verified information; no sales, tests or approvals are claimed.")
    listOf(
        "Introduction" to "SDAU Herbal Shampoo is a student entrepreneurship project.",
        "Objectives" to "Learn product development, costing and basic business planning.",
        "Product concept" to "A 100 ml herbal shampoo with a premium herbal brand look.",
        "Ingredients overview" to "Aloe Vera, Neem, Curry Leaves, Tulsi, Flaxseed (draft, to be confirmed).",
        "Packaging concept" to "100 ml bottle with cap and label; official logo to be added.",
        "Costing and business opportunity" to "Use the cost calculator to estimate cost per bottle and profit.",
        "Future scope" to "More variants, verified testing and proper approvals before any sale."
    ).forEach { (t, d) -> Section(t) { EditableField(store, "pr_$t", "Text", d, 3) } }
}

@Composable
fun AboutScreen(store: Store) = Page {
    Section("SDAU Herbal Shampoo") {
        Text("College Entrepreneurship Development Project")
        Text("A student project demonstration")
    }
    EditableField(store, "ab_name", "Student name", "")
    EditableField(store, "ab_dept", "Department", "")
    EditableField(store, "ab_college", "College details", "", 2)
    EditableField(store, "ab_guide", "Project guide", "")
}
