package com.sdau.herbal

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Forest = Color(0xFF1F3D2B)
val Olive = Color(0xFF6B7F3A)
val Cream = Color(0xFFF7F1E1)
val Gold = Color(0xFFC9A24B)

@Composable
fun SdauTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Forest, onPrimary = Cream,
            secondary = Olive, onSecondary = Color.White,
            tertiary = Gold, background = Cream, surface = Color.White,
            onBackground = Forest, onSurface = Color(0xFF22301F)
        ),
        content = content
    )
}
