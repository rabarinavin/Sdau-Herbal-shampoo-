package com.sdau.herbal

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

@Composable
fun Page(content: @Composable ColumnScope.() -> Unit) = Column(
    Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp), content = content
)

@Composable
fun Section(title: String, content: @Composable ColumnScope.() -> Unit) = Card(
    Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp),
    colors = CardDefaults.cardColors(containerColor = Color.White)
) {
    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title, fontFamily = FontFamily.Serif, fontSize = 19.sp, color = Forest)
        content()
    }
}

@Composable
fun Note(text: String) = Card(
    Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = Gold.copy(alpha = 0.22f))
) { Text(text, Modifier.padding(12.dp), fontSize = 13.sp, color = Forest) }

@Composable
fun Placeholder(label: String, size: Int, emoji: String) = Surface(
    shape = RoundedCornerShape(18.dp), color = Cream, border = BorderStroke(1.5.dp, Gold),
    modifier = Modifier.size(size.dp)
) {
    Column(Modifier.padding(6.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(emoji, fontSize = (size / 3).sp)
        Text(label, fontSize = 11.sp, textAlign = TextAlign.Center, color = Forest)
    }
}

/** Text that is saved locally on every edit. */
@Composable
fun EditableField(
    store: Store, key: String, label: String, def: String,
    minLines: Int = 1, numeric: Boolean = false
) {
    val saved by store.flow(key, def).collectAsState(initial = def)
    var local by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    OutlinedTextField(
        value = local ?: saved,
        onValueChange = {
            if (!numeric || (it.length <= 9 && it.all { c -> c.isDigit() || c == '.' })) {
                local = it
                scope.launch { store.set(key, it) }
            }
        },
        label = { Text(label) }, minLines = minLines,
        keyboardOptions = KeyboardOptions(keyboardType = if (numeric) KeyboardType.Decimal else KeyboardType.Text),
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
fun NumField(label: String, state: MutableState<String>, decimal: Boolean = true) = OutlinedTextField(
    value = state.value,
    onValueChange = { v ->
        if (v.length <= 9 && v.all { it.isDigit() || (decimal && it == '.') }) state.value = v
    },
    label = { Text(label) }, singleLine = true,
    keyboardOptions = KeyboardOptions(keyboardType = if (decimal) KeyboardType.Decimal else KeyboardType.Number),
    modifier = Modifier.fillMaxWidth()
)

@Composable
fun rs(initial: String = "") = rememberSaveable { mutableStateOf(initial) }
