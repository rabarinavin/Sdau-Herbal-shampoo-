# SDAU Herbal Shampoo (Android demo)
Kotlin, Jetpack Compose, Material 3, DataStore. minSdk 24. Fully offline.
## Build
1. Android Studio (Koala or newer, JDK 17): File > Open > this folder.
2. Wait for Gradle sync (needs internet once to download dependencies).
3. Run on a phone (USB debugging on) or an emulator.
4. Debug APK: Build > Build Bundle(s)/APK(s) > Build APK(s). Output: app/build/outputs/apk/debug/app-debug.apk
## Notes
- Replace the logo/product placeholders with real images (res/drawable) in Ui.kt/Screens.kt.
- Launcher icon: right-click res > New > Image Asset to use the official logo.
- Content is editable draft text; confirm ingredients and claims before real use.
